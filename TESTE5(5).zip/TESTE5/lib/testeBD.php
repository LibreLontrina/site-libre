<?php
include __DIR__ . '/../config/conexao.php';

echo '<h1>TESTE</h1>';
$conexao = new conexao();

$conexao->conn();







?>