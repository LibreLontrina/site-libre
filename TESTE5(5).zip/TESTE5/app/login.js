document.addEventListener('DOMContentLoaded', function() 
{
    loginVerif();  // A função será chamada automaticamente quando a página carregar
});
// caso eu não precise adicionar mais nada:
//document.addEventListener('DOMContentLoaded', loginVerif());

async function loginVerif()
{
    try
    {
        const dados = await fetch('/TESTE5/api/usuario/verifLogin');
        const resultado = await dados.json(); //O .json é oque faz funcionar, mas para
                                              //teste .TEXT é melhor para ver os erros
    
        if(resultado['status'] && resultado['status'] === true)
        {
            console.log('Verificação feita com sucesso');
            console.log(resultado);
            
            const nome = resultado['data']['nome'];
            const email = resultado['data']['email'];
    
            const lblnome = document.getElementById("nome");
            const lblemail = document.getElementById("email");
            
            lblnome.textContent = nome;
            lblemail.textContent = email;
            
    
        }
        else
        {
            console.log('Erro ao verificar o login do usuario');
            console.log(resultado);
        }
    
    
    }
    catch (E) //SignatureInvalidException
    {
        console.log('Alteração de chave inválida' + E);
    }

}


