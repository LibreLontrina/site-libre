<?php
define('DB_SERVER',   'localhost');
define('DB_NAME',     'bd');
define('DB_CHARSET',  'utf8');
define('DB_USER',     'root');
define('DB_PASSWORD', '');
?>