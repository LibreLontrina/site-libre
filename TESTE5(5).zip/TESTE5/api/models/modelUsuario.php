<?php
    require_once __DIR__ . "/../../config/conexao.php";
    require_once __DIR__ . "/../vendor/autoload.php";
    require_once __DIR__ . "/../services/jwtToken.php";

class modelUsuario
{
    public function criarUsuario($usuario) 
    {
        
        //dados da entidade
        $nome     = $usuario->getNome();
        $username = $usuario->getUsername();
        $email    = $usuario->getEmail();
        $tel      = $usuario->getTel();
        $dtaNasc  = $usuario->getDtaNasc(); 
        $senha    = password_hash($usuario->getSenha(), PASSWORD_DEFAULT);


        //array dos dados
        $conta = [
            'nome'     =>   $nome,
            'username' =>   $username,
            'email'    =>   $email,  
            'tel'      =>   $tel,
            'dtaNasc'  =>   $dtaNasc,
            'senha'    =>   $senha
        ];

        
        //$conexao = new conexao();
        //$verfEmail = $conexao->exe_query('SELECT id_usuario FROM usuarios WHERE email_usuario = (:email)',
        //                                $conta);

        //if(!empty($verfEmail))
        //{
        //    $mensagem = "Já existe uma conta com esse Email";
        //    $status = false;
        //
        //}
        //else
        //{
             //instancia de classe de conexão
            $conexao = new conexao();

            //função de execução da query, com os dados
            $bd = $conexao->exe_query('INSERT INTO usuarios(email_usuario, senha_usuario,
            apelido_usuario, username_usuario, telefone_usuario, data_nasc_usuario)
            VALUES (:email , :senha , :nome , :username , :tel , :dtaNasc)', $conta);

            if($bd > 0)
            {
                $mensagem = "Sucesso no cadastro";
                $status = true;
            }
            else
            {
                $mensagem = "Falha no cadastro";
                $status = false;
            }
        //}

        
        return[
            'mensagem' => $mensagem,
            'status' => $status
        ];
        

    }
    
    public function buscarLoginUsuario($dadoslogin) 
    {
        $login = $dadoslogin['login'];
        $senha = $dadoslogin['senha'];

        $logins = [
            'email' => $login,
            'usuario' => $login
        ];
        
        $conexao = new conexao();
        $dadosbd = $conexao->exe_query('SELECT id_usuario, senha_usuario FROM usuarios WHERE email_usuario = :email
        OR username_usuario = :usuario', $logins);
        
        if(!empty($senha) && !empty($dadosbd))
        {
            if(password_verify($senha, $dadosbd[0]['senha_usuario']))
            {
                $id = $dadosbd[0]['id_usuario'];
            
                $jwtToken = new jwtToken();
                $jwtToken->criarToken($id, 'usuario');

                $mensagem = 'As senhas e login batem, login com sucesso';
                $status = true;
            }
            else
            {
                $mensagem = 'Senha ou login não bate';
                $status = false;
            }
        }
        else
        {
            $mensagem = 'Nenhum usuario encontrado';
            $status = false;
        }

        return[
            'mensagem' => $mensagem,
            'status' => $status
        ];
    }

    public function verifLoginUsuario($dados)
    {
        $id = $dados['id'];
        $tipo = $dados['tipo'];
        
        $filtro = [
            'id' => $id
        ];
        
        $conexao = new conexao();
        $dadosbd = $conexao->exe_query('SELECT apelido_usuario, email_usuario FROM usuarios WHERE id_usuario = :id',
                                        $filtro);
        
        $data = [
            'id' => $id,
            'tipo' => $tipo,
            'nome' => $dadosbd[0]['apelido_usuario'],
            'email' => $dadosbd[0]['email_usuario']
        ];


        return[
            'status' => true,
            'message' => 'teste',
            'data' => $data
        ];
        //return $id;
    }

    public function buscarPerfilUsuario()
    {
        //das
    }

    public function update() //atualizar dados
    {
    
    }
    public function delete() //excluir conta
    {

    }
}

































?>