<?php

$uri = $_SERVER['REQUEST_URI'];
$uribase = '/TESTE5/api/';

if(strpos($uri, $uribase) === 0)
{
    $uri = substr($uri,strlen($uribase));
}

$endpoint = explode('/', trim($uri, '/'));

$entidade = $endpoint[0];
$acao = $endpoint[1];

$rotas = [
    'usuario' =>[
        'cadastrar' => ['controlUsuario', 'cadastrar'],
        'logar' => ['controlUsuario', 'logar'],
        'verifLogin' => ['controlUsuario','verifLogin'],
        'logout', //não sei se esse precisa
        'atualizar',
        'deletar',
        'PerfilAddFoto' => ['controlUsuario','AddFoto']
    ],
    'admin' =>[
        'cadastrar',
        'logar',
        'logout',
        'deletar'
    ],
    'livro' =>[
        'inserir',
        'pesquisar',
        'atualizar',
        'deletar'
    ]
];




if(isset($rotas[$entidade][$acao]))
{
    [$controller , $metodo] = $rotas[$entidade][$acao];

    require_once "controllers/{$controller}.php";
    $objController = new $controller();
    $objController->$metodo();

/*
    echo json_encode([
        'Controller:  ' => $controller,
        'Metodo:  ' => $metodo
        ]);

*/
}
else {
    http_response_code(404);
    echo json_encode(['erro' => 'Rota não encontrada']);
}









?>