<?php
require_once __DIR__ . '/../utils/validarUsuario.php';
require_once __DIR__ . '/../utils/sanitUsuario.php';
require_once __DIR__ . '/../entidades/entidUsuario.php';
require_once __DIR__ . '/../models/modelUsuario.php';
require_once __DIR__ . "/../services/response.php";


class controlUsuario
{
    function cadastrar() //não me esquecer de verificar se já tem contas com o email
    {
        
        //sanitizar os dados
        $sanitUsuario = new sanitUsuario();
        $dados = $sanitUsuario->sanitDados($_POST);
    
        //validar os dados
        $validUsuario = new validarUsuario();
        $erros = $validUsuario->validCadastro($dados);

        if(!empty($erros))
        {
            $mensagem = "Erros no cadastro";
            Response::criarResponse(false, $mensagem, $erros);
            return;
        }
    
        //guardar dados na entidade
        $Usuario = new entidUsuario();
        $Usuario->setDados($dados);
    
        //executar o modelo
        $modelUsuario = new modelUsuario();
        $resp = $modelUsuario->criarUsuario($Usuario);

        Response::criarResponse($resp['status'], $resp['mensagem']);
        
    }

    function logar()
    {
        $sanitLogin = new sanitUsuario();
        $dados = $sanitLogin->sanitDados($_POST);

        $modelUsuario = new modelUsuario();
        $resp = $modelUsuario->buscarLoginUsuario($dados);
        
        Response::criarResponse($resp['status'], $resp['mensagem']);
    
    }

    function verifLogin()
    {
        $cookie = $_COOKIE['token'];

        $classToken = new jwtToken();
        $dados = $classToken->verifToken($cookie);
        
        $dadosJson = (array) $dados;
        //$id = $dadosJson['id'];
        
        $modelUsuario = new modelUsuario();
        $resp = $modelUsuario->verifLoginUsuario($dadosJson);
        
        
        //Response::criarResponse(true, 'message', $id);
        Response::criarResponse($resp['status'], $resp['message'], $resp['data']);
    }

    function logout()
    {

    }
    function atualizar()
    {

    }
    function deletar()
    {

    }
}



























?>