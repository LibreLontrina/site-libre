<?php
class Response
{
    public static function criarResponse($status, $message, $data = null)
    {
        $resposta = [
            'status' => $status,
            'message' => $message
        ];

        if(!empty($data))
        {
            $resposta['data'] = $data;
        }

        echo json_encode($resposta);
        exit;
    }

}