<?php
    use Firebase\JWT\JWT;
    use Firebase\JWT\Key;

class jwtToken
{
    private $key = 'CHAVE_SUPER_SECRETA_QUE_TENHO_QUE_PENSAR_DEPOIS';

    public function criarToken($id, $tipo)
    {
        $chave = $this->key;
        $payload = [
            'id' =>   $id,
            'tipo' => $tipo
        ];

        $jwt = JWT::encode($payload, $chave, 'HS256');
        //$jwtdecoded = JWT::decode($jwt, new Key($chave, 'HS256'));

        $token = ($jwt);
        setcookie('token', $token, time() + 3600, '/', '', true, true);
    }

    public function verifToken($token)
    {
        $chave = $this->key;
        $jwtdecoded = JWT::decode($token, new Key($chave, 'HS256'));
        return $jwtdecoded;
    }





}















?>